# bird1 > 2022-11-29 1:08pm
https://universe.roboflow.com/mcmaster-v90vf/bird1-nmacp

Provided by a Roboflow user
License: CC BY 4.0

